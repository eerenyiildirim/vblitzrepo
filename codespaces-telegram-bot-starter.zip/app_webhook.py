import os
import asyncio
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

load_dotenv()
TOKEN = os.getenv("TELEGRAM_TOKEN")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "changeme")
APP_URL = os.getenv("APP_URL")
PORT = int(os.getenv("PORT", 8000))

if not TOKEN:
    raise SystemExit("TELEGRAM_TOKEN missing")

# Telegram bot app
app_tg = Application.builder().token(TOKEN).build()

async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Webhook hazır ✅")

app_tg.add_handler(CommandHandler("start", start_cmd))

# FastAPI HTTP app
api = FastAPI()

@api.get("/")
async def root():
    return {"ok": True}

@api.post(f"/webhook/{WEBHOOK_SECRET}")
async def telegram_webhook(request: Request):
    data = await request.json()
    await app_tg.update_queue.put(Update.de_json(data, app_tg.bot))
    return JSONResponse({"ok": True})

async def _run():
    if not APP_URL:
        print("APP_URL set edilmemiş. Codespaces 'Forward Port' sonrası public URL'yi APP_URL olarak koy.")
    else:
        wh_url = f"{APP_URL}/webhook/{WEBHOOK_SECRET}"
        print(f"Setting Telegram webhook → {wh_url}")
        await app_tg.bot.set_webhook(url=wh_url, drop_pending_updates=True)
    await app_tg.initialize()

# Uvicorn entrypoint:
# uvicorn app_webhook:api --host 0.0.0.0 --port 8000
if __name__ == "__main__":
    asyncio.run(_run())
