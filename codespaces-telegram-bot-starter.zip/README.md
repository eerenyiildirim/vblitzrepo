# Telegram Bot — GitHub Codespaces Starter

## Hızlı Başlangıç (Polling)
1) Repo → Code → Create codespace
2) Codespaces Secrets ekle: `TELEGRAM_TOKEN` (+ `CHAT_ID` opsiyonel)
3) Terminal:
```
pip install -r requirements.txt
python app.py
```
4) Telegram'da `/start` yaz → "Merhaba! Bot polling ile hazır ✅"

## Webhook (FastAPI)
1) Ports panelinde 8000'i Public yap, URL'yi kopyala (`APP_URL`)
2) Terminal:
```
export APP_URL="https://<codespaces-public-url>"
export WEBHOOK_SECRET="uzun-bir-deger"
python app_webhook.py
uvicorn app_webhook:api --host 0.0.0.0 --port 8000
```
3) Bot hazır; webhook set edilir.

## Prod Deploy (opsiyonel)
- Railway: `Procfile` var. Env: `TELEGRAM_TOKEN`, `WEBHOOK_SECRET`, `APP_URL`
- Render: `.github/workflows/deploy-render.yml` ile tetikleyebilirsin
- Railway: `.github/workflows/deploy-railway.yml`

> `.env` dosyasını commit'leme. Örnek için `.env.example` kullan.
